import React from 'react';

const BookingConfirmation = () => {
  return (
    <div>
      <h1>This is the Booking Confirmation page</h1>
    </div>
  );
};

export default BookingConfirmation;