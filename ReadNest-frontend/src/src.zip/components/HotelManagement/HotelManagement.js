import React from 'react';

const HotelManagement = () => {
    return (
        <div className="p-8">
            <h1 className="text-2xl font-bold">Hotel Management</h1>
            <p>This is the hotel management section.</p>
        </div>
    );
};

export default HotelManagement;
