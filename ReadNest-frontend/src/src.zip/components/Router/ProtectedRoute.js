import React from 'react';
import {jwtDecode} from 'jwt-decode';
import { getAuthToken } from '../../utils/authentication';

const ProtectedRoute = ({ children }) => {
  const token = getAuthToken();

  if (token) {
    try {
      const decoded = jwtDecode(token);
      if (decoded.role === 'ADMIN') {
        return children;
      }
    } catch (error) {
      console.error('Failed to decode token:', error);
    }
  }

  return (
    <div className="min-h-screen flex-col flex items-center justify-center">
      <h1 className="text-3xl font-bold text-red-600">FORBIDDEN ACCESS</h1>
      <p className="text-lg">You do not have permission to access this page.</p>
    </div>
  );
};

export default ProtectedRoute;
