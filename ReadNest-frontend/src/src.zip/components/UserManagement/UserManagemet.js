import React from 'react';

const UserManagement = () => {
    return (
        <div className="p-8">
            <h1 className="text-2xl font-bold">User Management</h1>
            <p>This is the user management section.</p>
        </div>
    );
};

export default UserManagement;
