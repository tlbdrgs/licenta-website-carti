import React from 'react';

const BookingManagement = () => {
    return (
        <div className="p-8">
            <h1 className="text-2xl font-bold">Booking Management</h1>
            <p>This is the booking management section.</p>
        </div>
    );
};

export default BookingManagement;
