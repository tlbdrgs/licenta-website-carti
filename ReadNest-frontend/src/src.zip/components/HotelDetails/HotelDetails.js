import React from 'react';

const HotelDetails = () => {
  return (
    <div>
      <h1>This is the Hotel Details page</h1>
    </div>
  );
};

export default HotelDetails;